# Development notes

Reviewer-facing context for `dynamo/reconcile-node-clocks`. Not shown to the agent.

## Regenerating the corpus and the ground truth

```bash
python3 tests/generate_fixtures.py                     # rewrites environment/data/logs/
docker build -t clocktask environment/                 # the corpus is baked into the image
docker run --rm -v "$PWD/solution:/solution:ro" \
           -v "$PWD/tests/expected:/out" \
           clocktask python3 /solution/pipeline.py /app/logs /out
```

Both steps are required in that order: `environment/data/logs/` is copied into the image at
build time, so regenerating the corpus without rebuilding leaves the container running against
stale logs. The expected outputs are produced by the reference solution rather than by the
generator, so `tests/expected/` stays a derivation rather than a hand-written answer key.

## Why the non-reference nodes log a monotonic clock

`node_alpha` logs UTC; the others log a free-running clock reading a few thousand seconds.
That is a deliberate numerical choice, not flavour. If every node logged raw Unix epochs
(~1.78e9), the textbook raw-sum least-squares formula would lose enough precision to
catastrophic cancellation that its fitted slope disagrees with the centered formula by ~0.27 s
of corrected time — 500x the half-millisecond rounding budget. A solver using the standard
formula would then fail through no fault of their own. With a small-magnitude regressor the two
agree to ~2e-6 s, so every reasonable implementation lands on the same answer.

## Determinism invariants

`tests/generate_fixtures.py` asserts all four on every run, and refuses to emit a corpus that
violates any of them:

| Invariant | Budget | Measured |
|---|---|---|
| Centered / raw-sum / `numpy.polyfit` agree on corrected time | 1e-5 s | 2.1e-6 s |
| No corrected time near a half-millisecond boundary | 1e-4 s | 0.5 (exactly on the grid) |
| Events on different nodes separated in corrected time | 2 ms | enforced by construction |
| No z-score near the 2.5 threshold | 1e-3 | 1.8e-3 |

The third is what makes ordering implementation-independent: exact timestamp collisions exist
only between events on the *same* node, where the corrected values are bit-identical, so the
`event_id` tie-break decides rather than floating-point noise.

## Anomaly threshold

The window is 20 records because the maximum attainable score in a window of $n$ using the
sample standard deviation is $(n-1)/\sqrt{n}$. At $n = 5$ that ceiling is 1.79, so a
$|z| > 2.5$ rule could never fire and every session would be unflagged. At $n = 20$ the
ceiling is 4.25 and the threshold is meaningful; 43 events in the corpus exceed it.

## Mutation testing

Each of these was applied to `solution/pipeline.py` and run through the full verifier.
Wrong readings must score 0; legitimate implementation variation must score 1.

| Mutation | Expected | Result |
|---|---|---|
| Duplicated `seq` kept (first wins) instead of dropped | fail | caught |
| Duplicated `seq` kept (last wins) instead of dropped | fail | caught |
| Duplicate `event_id` resolved last-wins instead of first-wins | fail | caught |
| Z-score window kept per user instead of globally | fail | caught |
| Population standard deviation instead of sample | fail | caught |
| Session gap `>= 300` instead of strictly `>` | fail | caught |
| Missing latency scored `0.0` instead of `null` | fail | caught |
| Textbook raw-sum OLS instead of centered | pass | passed |
| Sorting on rounded milliseconds instead of full precision | pass | passed |
| Reverse-direction OLS fit, then inverted | pass | passed |

The last three are fairness controls. The final one is worth noting for reviewers: because
heartbeat jitter is 3 ms against a 4-hour fit span, $r^2$ is within 5e-13 of 1 and the two
regression directions differ by ~4e-9 s of corrected time. The instruction fixes the direction
for determinism, but the task does not hinge on it, and a solver who fits the other way still
passes.

## Session-boundary coverage

`u03` carries two hand-placed gaps: exactly 300.000 s, which must *not* open a session, and
300.001 s, which must. All timestamps are emitted at millisecond precision, so the comparison
is exact integer arithmetic and the strict inequality is genuinely exercised.
