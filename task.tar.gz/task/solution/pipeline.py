#!/usr/bin/env python3
"""Reference solution: reconcile multi-node operational logs into a corrected timeline.

Stages: discover -> parse -> fit each node's clock onto the reference frame ->
normalise + quarantine -> order -> score latency -> segment sessions -> emit.
"""

from __future__ import annotations

import csv
import io
import json
import os
import re
import statistics
import sys
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP

LOGS_DIR = sys.argv[1] if len(sys.argv) > 1 else "/app/logs"
OUT_DIR = sys.argv[2] if len(sys.argv) > 2 else "/app/output"

REFERENCE_NODE = "node_alpha"
DATA_EXTENSIONS = (".log", ".jsonl", ".csv")

USER_ALIASES = ("uid", "user_id", "account")
TIME_ALIASES = ("ts", "timestamp", "time")

WINDOW = 20
Z_THRESHOLD = Decimal("2.5")
SESSION_GAP_MS = 300_000

HB_RE = re.compile(r"^\[HB_SYNC\s+(.*)\]$")
EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


# ---------------------------------------------------------------- primitives

def kv_pairs(text):
    """Split whitespace-separated key=value tokens into a dict, ignoring bare words."""
    out = {}
    for tok in text.split():
        if "=" in tok:
            k, _, v = tok.partition("=")
            out[k] = v
    return out


def parse_clock(raw):
    """Read a local clock reading: bare seconds, or an ISO-8601 UTC instant."""
    if raw is None:
        return None
    raw = str(raw).strip()
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        pass
    try:
        txt = raw[:-1] + "+00:00" if raw.endswith("Z") else raw
        dt = datetime.fromisoformat(txt)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.timestamp()


def parse_latency(raw):
    """Latency is optional; anything unreadable is treated as absent."""
    if raw is None:
        return None
    raw = str(raw).strip()
    if not raw:
        return None
    try:
        val = float(raw)
    except ValueError:
        return None
    return None if val != val else val


def pick(record, aliases):
    """Resolve a canonical field from its accepted aliases."""
    for key in aliases:
        if key in record and str(record[key]).strip():
            return str(record[key]).strip()
    return None


def half_up(value, places):
    """Round a float to `places` decimals, halves away from zero."""
    q = Decimal(1).scaleb(-places)
    return Decimal(value).quantize(q, rounding=ROUND_HALF_UP)


def to_millis(value):
    """Corrected epoch seconds -> integer milliseconds, rounding halves up."""
    return int((Decimal(value) * 1000).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def iso_from_millis(ms):
    """Integer epoch milliseconds -> ISO-8601 UTC with millisecond precision."""
    dt = EPOCH + timedelta(milliseconds=ms)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


def ols(xs, ys):
    """Least-squares fit of ys on xs, centered for numerical stability."""
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den = sum((x - mx) ** 2 for x in xs)
    slope = num / den
    return slope, my - slope * mx


# ------------------------------------------------------------------ ingestion

def discover():
    """Yield (node_id, relative_path, absolute_path) in lexicographic scan order."""
    found = []
    for root, dirs, files in os.walk(LOGS_DIR):
        dirs.sort()
        for name in sorted(files):
            if not name.endswith(DATA_EXTENSIONS):
                continue
            path = os.path.join(root, name)
            rel = os.path.relpath(path, LOGS_DIR)
            parts = rel.split(os.sep)
            if len(parts) < 2:
                continue
            found.append((parts[0], rel, path))
    found.sort(key=lambda item: item[1])
    return found


def read_lines(path):
    """Read a log file, tolerating a non-UTF-8 byte or two."""
    with open(path, "rb") as fh:
        blob = fh.read()
    try:
        text = blob.decode("utf-8")
    except UnicodeDecodeError:
        text = blob.decode("latin-1")
    return text.splitlines()


def rows_from(rel, lines):
    """Turn a file's lines into (record_or_None, is_marker, marker_text) triples.

    `record_or_None` is None when the line is structurally unparsable; markers are
    surfaced separately because they are control lines, not events.
    """
    ext = os.path.splitext(rel)[1]
    if ext == ".csv":
        header, body = None, []
        for raw in lines:
            if not raw.strip():
                continue
            marker = HB_RE.match(raw.strip())
            if marker:
                body.append((None, True, marker.group(1)))
                continue
            fields = next(csv.reader(io.StringIO(raw)))
            if header is None:
                header = fields
                continue
            body.append((dict(zip(header, fields)) if len(fields) == len(header) else None,
                         False, None))
        return body

    out = []
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        marker = HB_RE.match(line)
        if marker:
            out.append((None, True, marker.group(1)))
            continue
        if ext == ".jsonl":
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                obj = None
            out.append((obj if isinstance(obj, dict) else None, False, None))
        else:
            out.append((kv_pairs(line), False, None))
    return out


# ------------------------------------------------------------------- pipeline

def collect(files):
    """Scan every file once, splitting sync markers from candidate event records."""
    markers = {}       # node -> {seq: [reading, ...]}
    candidates = []    # (node, record) in scan order
    for node, rel, path in files:
        for record, is_marker, text in rows_from(rel, read_lines(path)):
            if is_marker:
                fields = kv_pairs(text)
                owner = fields.get("node", node)
                if "seq" not in fields:
                    continue
                reading = parse_clock(fields.get("ts"))
                if reading is None:
                    continue
                markers.setdefault(owner, {}).setdefault(fields["seq"], []).append(reading)
            else:
                candidates.append((node, record))
    return markers, candidates


def fit_clocks(markers):
    """Fit every node's local clock onto the reference node's frame."""
    def usable(node):
        return {s: v[0] for s, v in markers.get(node, {}).items() if len(v) == 1}

    reference = usable(REFERENCE_NODE)
    fits = {REFERENCE_NODE: (1.0, 0.0)}
    for node in markers:
        if node == REFERENCE_NODE:
            continue
        mine = usable(node)
        shared = sorted(set(mine) & set(reference))
        if len(shared) < 2:
            fits[node] = (1.0, 0.0)
        else:
            fits[node] = ols([mine[s] for s in shared], [reference[s] for s in shared])
    return fits


def normalise(candidates, fits):
    """Apply aliases, correct clocks, and quarantine anything unusable."""
    events, seen, quarantined = [], set(), 0
    for node, record in candidates:
        if record is None:
            quarantined += 1
            continue
        event_id = str(record["event_id"]).strip() if "event_id" in record else None
        user_id = pick(record, USER_ALIASES)
        local = parse_clock(pick(record, TIME_ALIASES))
        if not event_id or not user_id or local is None or event_id in seen:
            quarantined += 1
            continue
        seen.add(event_id)
        slope, intercept = fits.get(node, (1.0, 0.0))
        corrected = slope * local + intercept
        events.append({
            "event_id": event_id,
            "node_id": node,
            "user_id": user_id,
            "corrected": corrected,
            "millis": to_millis(corrected),
            "latency_ms": parse_latency(record.get("latency_ms")),
        })
    events.sort(key=lambda e: (e["corrected"], e["event_id"]))
    return events, quarantined


def score_latency(events):
    """Attach a trailing-window z-score to every event carrying a latency."""
    window = []
    for event in events:
        latency = event["latency_ms"]
        if latency is None:
            event["z_score"] = None
            continue
        window.append(latency)
        if len(window) > WINDOW:
            window.pop(0)
        if len(window) < WINDOW:
            event["z_score"] = Decimal("0.000000")
            continue
        sd = statistics.stdev(window)
        if sd == 0.0:
            event["z_score"] = Decimal("0.000000")
        else:
            event["z_score"] = half_up((latency - statistics.fmean(window)) / sd, 6)


def segment(events):
    """Split each user's events into sessions on inactivity gaps over the limit."""
    sessions, open_session = [], {}
    for event in events:
        user = event["user_id"]
        current = open_session.get(user)
        if current is None or event["millis"] - current["last"] > SESSION_GAP_MS:
            current = {"user": user, "first": event["millis"], "last": event["millis"],
                       "count": 0, "anomaly": False}
            sessions.append(current)
            open_session[user] = current
        current["last"] = event["millis"]
        current["count"] += 1
        z = event["z_score"]
        if z is not None and abs(z) > Z_THRESHOLD:
            current["anomaly"] = True
    return sessions


def session_id(session):
    """Name a session by its user and the whole second its first event falls in."""
    stamp = (EPOCH + timedelta(seconds=session["first"] // 1000)).strftime("%Y%m%d%H%M%S")
    return f"{session['user']}_{stamp}"


def emit(events, quarantined, sessions):
    """Write the corrected timeline and the per-session anomaly report."""
    os.makedirs(OUT_DIR, exist_ok=True)

    payload = {
        "quarantined_count": quarantined,
        "events": [{
            "event_id": e["event_id"],
            "node_id": e["node_id"],
            "user_id": e["user_id"],
            "timestamp": iso_from_millis(e["millis"]),
            "latency_ms": e["latency_ms"],
            "z_score": None if e["z_score"] is None else float(e["z_score"]),
        } for e in events],
    }
    with open(os.path.join(OUT_DIR, "global_timeline.json"), "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
        fh.write("\n")

    rows = sorted(
        (session_id(s), s["count"], (s["last"] - s["first"]) / 1000.0, s["anomaly"])
        for s in sessions
    )
    with open(os.path.join(OUT_DIR, "session_anomalies.csv"), "w", encoding="utf-8",
              newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["session_id", "total_events", "duration_seconds", "anomaly_flag"])
        for sid, count, duration, flag in rows:
            writer.writerow([sid, count, f"{duration:.6f}", "true" if flag else "false"])


def main():
    markers, candidates = collect(discover())
    fits = fit_clocks(markers)
    events, quarantined = normalise(candidates, fits)
    score_latency(events)
    sessions = segment(events)
    emit(events, quarantined, sessions)
    print(f"events={len(events)} quarantined={quarantined} sessions={len(sessions)}")


if __name__ == "__main__":
    main()
