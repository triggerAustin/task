#!/bin/bash
set -euo pipefail
python3 /solution/pipeline.py /app/logs /app/output
