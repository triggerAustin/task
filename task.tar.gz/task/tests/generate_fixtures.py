#!/usr/bin/env python3
"""Deterministic generator for the raw log corpus under environment/data/logs/.

This script emits ONLY the agent-visible input data. It contains no pipeline
logic: the expected outputs are produced by running solution/pipeline.py over the
corpus emitted here (see task/README.md).

Invariants asserted at the bottom of this file, each of which the task's
determinism depends on:

  1. Every OLS variant (centered, textbook raw-sum, numpy.polyfit) must agree on
     corrected time to well under a millisecond. Regressing the reference node's
     UTC on a raw ~1.78e9 epoch column suffers catastrophic cancellation in the
     raw-sum formula and disagrees by ~0.27 s; that is why non-reference nodes log
     a small-magnitude free-running clock instead.
  2. No corrected timestamp lies within 1e-4 s of a half-millisecond boundary, so
     millisecond rounding is never a coin flip.
  3. Events on *different* nodes are >= 2 ms apart in corrected time, so
     floating-point noise in the fit can never reorder the global timeline. Exact
     ties exist only between events on the *same* node, where corrected times are
     bit-identical and the event_id tie-break decides.
  4. No |z-score| lies within 1e-3 of the 2.5 anomaly threshold.
"""

from __future__ import annotations

import gzip
import json
import math
import os
import random
import shutil
import statistics
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
LOGS = os.path.normpath(os.path.join(HERE, "..", "environment", "data", "logs"))

SEED = 20260615
BASE = datetime(2026, 6, 15, 9, 0, 0, tzinfo=timezone.utc).timestamp()

HB_COUNT = 40
HB_PERIOD = 360.0

WINDOW = 20
Z_THRESHOLD = 2.5
SESSION_GAP = 300.0

USERS = [f"u{i:02d}" for i in range(1, 13)]

# node -> clock model.
#   reference: the local clock *is* the corrected UTC frame.
#   monotonic: local reading = (utc - boot) * rate   (free-running since boot)
#   wall:      local reading = utc + offset          (unsynchronised wall clock)
NODES = {
    "node_alpha":   {"kind": "reference"},
    "node_beta":    {"kind": "monotonic", "boot": BASE - 3000.0,  "rate": 1.0000042},
    "node_gamma":   {"kind": "monotonic", "boot": BASE - 11000.0, "rate": 0.9999871},
    "node_delta":   {"kind": "monotonic", "boot": BASE - 700.0,   "rate": 1.0000118},
    "node_epsilon": {"kind": "wall",      "offset": 900.0},
}
NODE_ORDER = list(NODES)

GAMMA_MISSING = {4, 9, 17, 28, 33}
DELTA_MAX_SEQ = 25
DELTA_DUP_SEQ = 7
DELTA_NOSEQ_AFTER = 11
ALPHA_DUP_SEQ = 12
EPSILON_SEQS = [3, 101, 102, 103]

# Window reserved for the deliberate session-gap boundary cases.
BOUNDARY_USER = "u03"
BOUNDARY_T0 = BASE + 4000.0
BOUNDARY_SPAN = (BOUNDARY_T0 - 400.0, BOUNDARY_T0 + 1200.0)


def iso_ms(epoch: float) -> str:
    """Format an epoch second as ISO-8601 UTC with millisecond precision."""
    dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(
        milliseconds=round(epoch * 1000.0)
    )
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"


def ols_centered(xs, ys):
    """Least-squares fit of ys on xs via the centered formula."""
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den = sum((x - mx) ** 2 for x in xs)
    slope = num / den
    return slope, my - slope * mx


def ols_rawsum(xs, ys):
    """Textbook raw-sum OLS; used only to assert implementation independence."""
    n = len(xs)
    sx, sy = sum(xs), sum(ys)
    sxy = sum(x * y for x, y in zip(xs, ys))
    sxx = sum(x * x for x in xs)
    slope = (n * sxy - sx * sy) / (n * sxx - sx * sx)
    return slope, (sy - slope * sx) / n


def local_reading(node: str, utc: float) -> float:
    """Map a true UTC instant to what `node`'s own clock would read."""
    cfg = NODES[node]
    if cfg["kind"] == "reference":
        return utc
    if cfg["kind"] == "monotonic":
        return (utc - cfg["boot"]) * cfg["rate"]
    return utc + cfg["offset"]


def build_heartbeats(rng):
    """Emit consensus heartbeat instants plus each node's recorded local reading."""
    true_times = [
        round(BASE + HB_PERIOD * k + rng.uniform(-1.5, 1.5), 3) for k in range(HB_COUNT)
    ]
    readings = {}
    for node in NODE_ORDER:
        jitter = 0.0 if node == "node_alpha" else 0.003
        readings[node] = [
            local_reading(node, t) + (rng.uniform(-jitter, jitter) if jitter else 0.0)
            for t in true_times
        ]
    return true_times, readings


def hb_line(node, seq, reading):
    """Render one broadcast sync marker as it appears in a node's app log."""
    ts = iso_ms(reading) if NODES[node]["kind"] in ("reference", "wall") else f"{reading:.6f}"
    if seq is None:
        return f"[HB_SYNC node={node} ts={ts}]"
    return f"[HB_SYNC node={node} seq={seq} ts={ts}]"


def heartbeat_markers(node, readings):
    """Build the (seq, line) markers a node writes, including its logging defects."""
    out = []
    if node == "node_alpha":
        for k in range(HB_COUNT):
            out.append((k, hb_line(node, k, readings[node][k])))
            if k == ALPHA_DUP_SEQ:
                # Replayed marker: correct line first, stale copy second.
                out.append((k, hb_line(node, k, readings[node][k - 1])))
    elif node == "node_beta":
        for k in range(HB_COUNT):
            out.append((k, hb_line(node, k, readings[node][k])))
    elif node == "node_gamma":
        for k in range(HB_COUNT):
            if k not in GAMMA_MISSING:
                out.append((k, hb_line(node, k, readings[node][k])))
    elif node == "node_delta":
        for k in range(DELTA_MAX_SEQ):
            if k == DELTA_DUP_SEQ:
                # Replayed marker, this time stale copy first and correct line second,
                # so neither "keep the first" nor "keep the last" recovers the fit.
                out.append((k, hb_line(node, k, readings[node][k - 1])))
            out.append((k, hb_line(node, k, readings[node][k])))
            if k == DELTA_NOSEQ_AFTER:
                out.append((None, hb_line(node, None, readings[node][k])))
    else:
        for s in EPSILON_SEQS:
            out.append((s, hb_line(node, s, readings[node][min(s, HB_COUNT - 1)])))
    return out


def usable_seqs(node, readings):
    """Sequence numbers a node contributes after dropping duplicates and blanks."""
    seen, dup = set(), set()
    for seq, _ in heartbeat_markers(node, readings):
        if seq is None:
            continue
        if seq in seen:
            dup.add(seq)
        seen.add(seq)
    return seen - dup


def fit_nodes(true_times, readings):
    """Fit each non-reference node's local clock onto the reference UTC frame."""
    ref = {s: true_times[s] for s in usable_seqs("node_alpha", readings) if s < HB_COUNT}
    fits, pair_counts = {"node_alpha": (1.0, 0.0)}, {"node_alpha": None}
    for node in NODE_ORDER[1:]:
        pairs = [
            (readings[node][s], ref[s])
            for s in sorted(usable_seqs(node, readings))
            if s in ref and s < HB_COUNT
        ]
        pair_counts[node] = len(pairs)
        if len(pairs) < 2:
            fits[node] = (1.0, 0.0)
        else:
            fits[node] = ols_centered([p[0] for p in pairs], [p[1] for p in pairs])
    return fits, pair_counts


def design_sessions(rng):
    """Lay out per-user activity bursts directly in corrected-time space."""
    events = []
    for user in USERS:
        t = BASE + 200.0 + rng.uniform(0, 600.0)
        while t < BASE + 13700.0:
            for _ in range(rng.randint(4, 26)):
                events.append([round(t, 3), user])
                t += round(rng.uniform(0.6, 55.0), 3)
            t += round(rng.uniform(330.0, 900.0), 3)
    # Keep the boundary window clear so the deliberate gaps below are not split.
    events = [
        e for e in events
        if not (e[1] == BOUNDARY_USER and BOUNDARY_SPAN[0] <= e[0] <= BOUNDARY_SPAN[1])
    ]
    t0 = BOUNDARY_T0
    a = t0 + 12.5
    b = a + SESSION_GAP           # exactly 300.000 s -> same session
    c = b + 40.0
    d = c + SESSION_GAP + 0.001   # 300.001 s -> new session
    for t in (t0, a, b, c, d, d + 9.0):
        events.append([round(t, 3), BOUNDARY_USER])
    events.sort(key=lambda e: e[0])
    return events


def assign_nodes(events, rng):
    """Assign a node per event, forcing sub-2 ms neighbours onto the same node."""
    out, prev_t, prev_node = [], None, None
    for t, user in events:
        node = prev_node if (prev_t is not None and t - prev_t < 0.002) else rng.choice(NODE_ORDER)
        out.append({"t": t, "user": user, "node": node})
        prev_t, prev_node = t, node
    return out


def attach_latencies(records, rng):
    """Give each event a latency: healthy baseline, spikes, and one stuck-sensor run."""
    n = len(records)
    stuck = set(range(n // 2, n // 2 + WINDOW + 4))
    spikes = set(rng.sample([i for i in range(WINDOW + 5, n - 5) if i not in stuck], 26))
    for i, r in enumerate(records):
        if i in stuck:
            r["lat"] = 50.0
        elif i in spikes:
            r["lat"] = round(rng.uniform(700.0, 1400.0), 3)
        else:
            r["lat"] = max(1.0, round(rng.gauss(85.0, 11.0), 3))
    for i in rng.sample([i for i in range(n) if i not in stuck], 45):
        records[i]["lat"] = None
    for i, r in enumerate(records):
        r["event_id"] = f"evt-{i:05d}"
    return stuck


def add_ties(records, stuck, rng):
    """Create same-node exact timestamp collisions resolved only by event_id."""
    n = len(records)
    picks = rng.sample([i for i in range(60, n - 60) if i not in stuck], 6)
    partners = []
    for i in picks:
        r = records[i]
        partners.append({
            "t": r["t"], "user": r["user"], "node": r["node"],
            "lat": max(1.0, round(rng.gauss(85.0, 11.0), 3)),
            # Shares the original's corrected time exactly; write_corpus emits this
            # partner *before* the original so raw file order cannot stand in for
            # the required (timestamp, event_id) ordering.
            "event_id": f"evt-{i:05d}A",
        })
    records.extend(partners)
    records.sort(key=lambda r: (r["t"], r["event_id"]))
    return {p["event_id"] for p in partners}


def zscores(records):
    """Trailing-window z-scores over the globally ordered timeline, as the spec defines."""
    win, out = [], []
    for r in records:
        if r["lat"] is None:
            out.append(None)
            continue
        win.append(r["lat"])
        if len(win) > WINDOW:
            win.pop(0)
        if len(win) < WINDOW:
            out.append(0.0)
            continue
        sd = statistics.stdev(win)
        out.append(0.0 if sd == 0.0 else (r["lat"] - statistics.fmean(win)) / sd)
    return out


def fmt_local(node, corrected, fits):
    """Invert a node's fitted clock model to the local reading it would have logged."""
    a, b = fits[node]
    local = (corrected - b) / a
    if NODES[node]["kind"] in ("reference", "wall"):
        return iso_ms(local)
    return f"{local:.6f}"


ALIASES = {
    ("node_alpha", "log"): ("user_id", "timestamp"),
    ("node_alpha", "jsonl"): ("uid", "ts"),
    ("node_beta", "log"): ("account", "ts"),
    ("node_beta", "csv"): ("uid", "time"),
    ("node_gamma", "log"): ("uid", "time"),
    ("node_gamma", "jsonl"): ("user_id", "timestamp"),
    ("node_delta", "log"): ("account", "timestamp"),
    ("node_delta", "csv"): ("user_id", "ts"),
    ("node_epsilon", "log"): ("uid", "ts"),
}
SECOND_FILE = {
    "node_alpha": "jsonl", "node_beta": "csv", "node_gamma": "jsonl",
    "node_delta": "csv", "node_epsilon": None,
}


def write_corpus(records, readings, fits, tie_ids):
    """Serialise every node's log files, interleaving markers, events and defects."""
    # Tie partners are written before their originals so that raw file order does
    # not already match the required (timestamp, event_id) ordering.
    write_order = list(records)
    for i in range(len(write_order) - 1):
        a, b = write_order[i], write_order[i + 1]
        if a["t"] == b["t"] and b["event_id"] in tie_ids:
            write_order[i], write_order[i + 1] = b, a

    by_node = {nd: [] for nd in NODE_ORDER}
    for r in write_order:
        by_node[r["node"]].append(r)

    for node in NODE_ORDER:
        rows = by_node[node]
        kind2 = SECOND_FILE[node]
        log_rows, alt_rows = [], []
        for i, r in enumerate(rows):
            (alt_rows if (kind2 and i % 2) else log_rows).append(r)

        uk, tk = ALIASES[(node, "log")]
        lines, markers = [], heartbeat_markers(node, readings)
        stride = max(1, len(log_rows) // max(1, len(markers)))
        it = iter(markers)
        for i, r in enumerate(log_rows):
            if i % stride == 0:
                nxt = next(it, None)
                if nxt is not None:
                    lines.append(nxt[1])
            parts = [f"event_id={r['event_id']}", f"{uk}={r['user']}",
                     f"{tk}={fmt_local(node, r['t'], fits)}", f"host={node}"]
            if r["lat"] is not None:
                parts.append(f"latency_ms={r['lat']}")
            lines.append("level=INFO " + " ".join(parts))
        lines.extend(m[1] for m in it)
        inject_log_defects(lines, node)
        if node == "node_gamma":
            # Same event_id twice within one file: the later line is quarantined.
            dup = log_rows[3]
            lines.append(
                f"level=INFO event_id={dup['event_id']} {uk}={dup['user']} "
                f"{tk}={fmt_local(node, dup['t'] + 4.0, fits)} host={node} latency_ms=61.5"
            )
        write_lines(os.path.join(LOGS, node, "app.log"), lines)

        if kind2 == "jsonl":
            uk, tk = ALIASES[(node, "jsonl")]
            out = []
            for r in alt_rows:
                obj = {"event_id": r["event_id"], uk: r["user"],
                       tk: fmt_local(node, r["t"], fits), "svc": "ingest"}
                if r["lat"] is not None:
                    obj["latency_ms"] = r["lat"]
                out.append(json.dumps(obj))
            inject_jsonl_defects(out)
            if node == "node_alpha":
                # Re-emission of an id already carried by app.log, which is scanned
                # first: this copy is quarantined and the app.log copy survives.
                dup = log_rows[5]
                out.append(json.dumps({
                    "event_id": dup["event_id"], uk: dup["user"],
                    tk: fmt_local(node, dup["t"] + 7.5, fits),
                    "svc": "retry", "latency_ms": 133.25,
                }))
            write_lines(os.path.join(LOGS, node, "events.jsonl"), out)
        elif kind2 == "csv":
            uk, tk = ALIASES[(node, "csv")]
            out = [f"event_id,{uk},{tk},latency_ms"]
            for r in alt_rows:
                lat = "" if r["lat"] is None else r["lat"]
                out.append(f"{r['event_id']},{r['user']},{fmt_local(node, r['t'], fits)},{lat}")
            inject_csv_defects(out)
            if node == "node_beta":
                dup = log_rows[5]
                out.append(f"{dup['event_id']},{dup['user']},"
                           f"{fmt_local(node, dup['t'] + 3.25, fits)},58.0")
            write_lines(os.path.join(LOGS, node, "metrics.csv"), out)

    with gzip.open(os.path.join(LOGS, "node_gamma", "archive.jsonl.gz"), "wt") as fh:
        fh.write(json.dumps({"event_id": "evt-99999", "uid": "u01",
                             "ts": "9999.000000", "latency_ms": 5.0}) + "\n")
    write_lines(os.path.join(LOGS, "node_delta", "notes.txt"),
                ["rotated by logrotate; see runbook"])


def inject_log_defects(lines, node):
    """Blank line, a record with no user field, junk text, and a bad timestamp."""
    lines.insert(len(lines) // 3, "")
    lines.insert(len(lines) // 2, f"level=INFO event_id=bad-01-{node} host={node} latency_ms=12.0")
    lines.insert(2 * len(lines) // 3, "level=WARN this line has no key value pairs at all")
    lines.append(f"level=INFO event_id=bad-02-{node} user_id=u04 timestamp=not-a-timestamp")


def inject_jsonl_defects(out):
    """Truncated JSON, a record with no user field, and a record with no event_id."""
    out.insert(len(out) // 4, '{"event_id": "evt-broken", "uid": "u02", "ts": ')
    out.insert(len(out) // 2, json.dumps({"event_id": "bad-03", "ts": "12.0", "latency_ms": 9.0}))
    out.append(json.dumps({"uid": "u05", "ts": "13.0", "latency_ms": 9.0}))


def inject_csv_defects(out):
    """A short row and a row whose timestamp field is empty."""
    out.insert(len(out) // 3, "bad-04,u06")
    out.append("bad-05,u07,,41.0")


def write_lines(path, lines):
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def run_assertions(records, readings, fits, pair_counts):
    """Fail loudly if any invariant the task's determinism depends on is violated."""
    # (1) Implementation independence of the fit.
    try:
        import numpy as np
    except ImportError:
        np = None
    worst_fit = 0.0
    for node in NODE_ORDER[1:]:
        if pair_counts[node] < 2:
            continue
        ref = {s: t for s, t in zip(range(HB_COUNT), readings["node_alpha"])}
        seqs = [s for s in sorted(usable_seqs(node, readings))
                if s in usable_seqs("node_alpha", readings) and s < HB_COUNT]
        xs = [readings[node][s] for s in seqs]
        ys = [ref[s] for s in seqs]
        cands = [ols_centered(xs, ys), ols_rawsum(xs, ys)]
        if np is not None:
            c = np.polyfit(np.array(xs), np.array(ys), 1)
            cands.append((float(c[0]), float(c[1])))
        locals_ = [(r["t"] - fits[node][1]) / fits[node][0]
                   for r in records if r["node"] == node]
        for x in locals_:
            vals = [a * x + b for a, b in cands]
            worst_fit = max(worst_fit, max(vals) - min(vals))
    assert worst_fit < 1e-5, f"OLS variants disagree by {worst_fit:.3e} s"

    # (2) Half-millisecond clearance.
    worst_round = 1.0
    for r in records:
        ms = r["t"] * 1000.0
        worst_round = min(worst_round, abs(ms - math.floor(ms) - 0.5))
    assert worst_round > 1e-4, f"timestamp within {worst_round:.2e} of a half-ms boundary"

    # (3) Cross-node separation.
    for a, b in zip(records, records[1:]):
        if a["node"] != b["node"]:
            assert b["t"] - a["t"] >= 0.002 - 1e-9, f"cross-node events {a} {b} too close"

    # (4) z-scores clear of the threshold.
    zs = [z for z in zscores(records) if z is not None]
    margin = min(abs(abs(z) - Z_THRESHOLD) for z in zs)
    assert margin > 1e-3, f"a |z| sits {margin:.2e} from the {Z_THRESHOLD} threshold"

    anomalies = sum(1 for z in zs if abs(z) > Z_THRESHOLD)
    print(f"corpus: {len(records)} events, {len(zs)} with latency, {anomalies} anomalous")
    print(f"  OLS variant spread   {worst_fit:.3e} s   (budget 1e-5)")
    print(f"  half-ms clearance    {worst_round:.3e}    (budget 1e-4)")
    print(f"  z-threshold margin   {margin:.3e}       (budget 1e-3)")
    for node in NODE_ORDER:
        print(f"  {node:14s} pairs={pair_counts[node]}  fit={fits[node]}")


def main():
    rng = random.Random(SEED)
    if os.path.isdir(LOGS):
        shutil.rmtree(LOGS)
    for node in NODE_ORDER:
        os.makedirs(os.path.join(LOGS, node), exist_ok=True)

    true_times, readings = build_heartbeats(rng)
    fits, pair_counts = fit_nodes(true_times, readings)

    records = assign_nodes(design_sessions(rng), rng)
    stuck = attach_latencies(records, rng)
    tie_ids = add_ties(records, stuck, rng)

    write_corpus(records, readings, fits, tie_ids)
    run_assertions(records, readings, fits, pair_counts)


if __name__ == "__main__":
    main()
