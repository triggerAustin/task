#!/bin/bash
# Runs the verifier inside the task's environment image. All dependencies are baked
# into environment/Dockerfile, so nothing is installed here.
set -uo pipefail

mkdir -p /logs/verifier

python3 -m pytest /tests/test_outputs.py \
    -v --tb=short -p no:cacheprovider \
    --ctrf /logs/verifier/ctrf.json
status=$?

if [ "$status" -eq 0 ]; then
    printf '1' > /logs/verifier/reward.txt
else
    printf '0' > /logs/verifier/reward.txt
fi

exit 0
